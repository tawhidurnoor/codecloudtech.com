@extends('backend.layouts.full.mainlayout')

@section('title')
@endsection

@section('styles')
@endsection

@section('page-title')
@endsection

@section('body')
@endsection

@section('scripts')
@endsection
