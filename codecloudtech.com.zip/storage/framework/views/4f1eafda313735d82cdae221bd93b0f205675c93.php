<div class="loader-content">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="sk-folding-cube">
                <div class="sk-cube1 sk-cube"></div>
                <div class="sk-cube2 sk-cube"></div>
                <div class="sk-cube4 sk-cube"></div>
                <div class="sk-cube3 sk-cube"></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Tawhidur Noor Badhan\codecloudtech.com\resources\views/frontend/layouts/partials/loader.blade.php ENDPATH**/ ?>