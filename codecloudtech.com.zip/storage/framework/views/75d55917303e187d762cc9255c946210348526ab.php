<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="app-url" content="<?php echo e(getBaseURL()); ?>">
<meta name="file-base-url" content="<?php echo e(getFileBaseURL()); ?>">

<meta name="description" content="<?php echo e(getMetaDescription()); ?>" />
<meta name="keywords" content="<?php echo e(getMetaKeywords()); ?>">
<meta property="og:image" content="<?php echo e(URL::asset('daynamic_files/' . getMetaImage())); ?>" />
<?php /**PATH E:\Tawhidur Noor Badhan\codecloudtech.com\resources\views/frontend/layouts/partials/meta.blade.php ENDPATH**/ ?>