<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center">
    All Rights Reserved by CodeCloud Technology.
</footer>
<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->
<?php /**PATH E:\Tawhidur Noor Badhan\codecloudtech.com\resources\views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>