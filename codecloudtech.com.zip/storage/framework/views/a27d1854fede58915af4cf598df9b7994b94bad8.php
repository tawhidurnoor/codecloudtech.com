<link rel="stylesheet" href="assets_frontend/css/bootstrap.min.css">

<link rel="stylesheet" href="assets_frontend/css/meanmenu.min.css" />

<link rel="stylesheet" href="assets_frontend/css/boxicons.min.css" />

<link rel="stylesheet" href="assets_frontend/css/flaticon.css" />

<link rel="stylesheet" href="assets_frontend/css/magnific-popup.min.css" />

<link rel="stylesheet" href="assets_frontend/css/animate.min.css" />

<link rel="stylesheet" href="assets_frontend/css/owl.carousel.min.css" />

<link rel="stylesheet" href="assets_frontend/css/style.css" />

<link rel="stylesheet" href="assets_frontend/css/dark.css" />

<link rel="stylesheet" href="assets_frontend/css/responsive.css" />

<link rel="icon" type="image/png" href="assets_frontend/images/favicon.png" />
<?php /**PATH E:\Tawhidur Noor Badhan\codecloudtech.com\resources\views/frontend/layouts/partials/styles.blade.php ENDPATH**/ ?>