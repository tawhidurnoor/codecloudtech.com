<header class="header-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-2 col-sm-0">
                <div class="logo">
                    <a href="index.html">
                        <script type="text/javascript" style="display:none">
                            //<![CDATA[
                            window.__mirage2 = {
                                petok: "ba344a321c135ff00f5b89431d43414a050761e9-1652165618-1800"
                            };
                            //]]>
                        </script>
                        <script type="text/javascript" src="assets_frontend/js/mirage2.min.js"></script>
                        <img data-cfsrc="assets_frontend/images/logo.png" alt="logo"
                            style="display:none;visibility:hidden;" /><noscript><img src="assets_frontend/images/logo.png"
                                alt="logo" /></noscript>
                    </a>
                </div>
            </div>
            <div class="col-lg-8 col-sm-8 text-right pr-0">
                <div class="header-content-right">
                    <ul class="header-contact">
                        <li><a href="tel:+1123456789"><i class="bx bxs-phone-call"></i> +1 123 456 789</a></li>
                        <li><a
                                href="https://templates.hibootstrap.com/cdn-cgi/l/email-protection#4b232e2727240b3b2a382465282426"><i
                                    class="bx bxs-envelope"></i> <span class="__cf_email__"
                                    data-cfemail="9bf3fef7f7f4dbebfae8f4b5f8f4f6">[email&#160;protected]</span></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-sm-4 text-right pl-0">
                <div class="header-content-right">
                    <ul class="header-social">
                        <li>
                            <a href="#" target="_blank"><i class="bx bxl-facebook"></i></a>
                        </li>
                        <li>
                            <a href="#" target="_blank"><i class="bx bxl-twitter"></i></a>
                        </li>
                        <li>
                            <a href="#" target="_blank"> <i class="bx bxs-envelope"></i></a>
                        </li>
                        <li>
                            <a href="#" target="_blank"> <i class="bx bxl-youtube"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH E:\Tawhidur Noor Badhan\codecloudtech.com\resources\views/frontend/layouts/partials/header.blade.php ENDPATH**/ ?>